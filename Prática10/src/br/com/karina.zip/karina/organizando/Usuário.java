package br.com.karina.organizando;

public class Usuário {
    private String nome;

    public void setNome(String nome) {
        this.nome = nome;
    }
}
